"""Generate the self-driving car wiring schematic (KiCad) for car_model.

Run:  python gen_schematic.py
Writes autonomous_car.kicad_sch / .kicad_pro / autocar.kicad_sym / sym-lib-table next to this script.

Module-level wiring diagram: every board (ESP32 DevKit V1, TB6612FNG breakout, VL53L0X, MPU6050 ...) is a
custom box symbol with the module's own pin names; connections are made with net labels and power symbols
(GND, +5V, +3V3, +BATT) at the end of a short wire stub on each pin, unused pins get a no-connect flag.
Pin plan follows https://yoshiagent.github.io/MechanicalAI/autonomous/electronics/ (section 四).
Power symbols / PWR_FLAG are copied from KiCad's own power library.
"""
import os
import re
import uuid as _uuid

HERE = os.path.dirname(os.path.abspath(__file__))
KICAD_SYM = r"C:\Users\USER\AppData\Local\Programs\KiCad\10.0\share\kicad\symbols"
PROJECT = "autonomous_car"
LIB = "autocar"
G = 2.54
ROOT_UUID = str(_uuid.uuid5(_uuid.NAMESPACE_URL, "mechanicalai/autonomous_car/root"))
_n = [0]


def uid():
    _n[0] += 1
    return str(_uuid.uuid5(_uuid.NAMESPACE_URL, f"mechanicalai/autonomous_car/{_n[0]}"))


def q(s):
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'


def f(v):
    return f"{v:.3f}".rstrip("0").rstrip(".")


def font(size=1.27, extra=""):
    return f"(effects (font (size {f(size)} {f(size)})){extra})"


# ---------------------------------------------------------------- custom module symbols
class Module:
    """Box symbol: pins = list of (name, type) per side; None in a list leaves an empty slot."""

    def __init__(self, name, ref, value, left=(), right=(), width=7, desc=""):
        self.name, self.ref, self.value, self.desc = name, ref, value, desc
        self.left, self.right = list(left), list(right)
        self.hw = width * G  # half width, a multiple of G so pins stay on the 2.54 grid
        rows = max(len(self.left), len(self.right))
        self.top = G * (rows // 2 + 1)
        self.bottom = self.top - G * (rows + 1)
        self.pins = {}  # name -> (x, y, angle) in symbol coordinates (y up)
        num = 1
        self.numbers = {}
        for side, ang, x in ((self.left, 0, -self.hw - G), (self.right, 180, self.hw + G)):
            for i, p in enumerate(side):
                if p is None:
                    continue
                y = self.top - G * (i + 1)
                self.pins[p[0]] = (x, y, ang, p[1])
                self.numbers[p[0]] = str(num)
                num += 1

    def lib_text(self, lib_prefix=True):
        nm = f"{LIB}:{self.name}" if lib_prefix else self.name
        out = [f'(symbol {q(nm)} (pin_numbers (hide yes)) (pin_names (offset 0.508)) (exclude_from_sim no) '
               f'(in_bom yes) (on_board yes)',
               f'(property "Reference" {q(self.ref)} (at {f(-self.hw)} {f(self.top + 1.27)} 0) {font(1.27, " (justify left bottom)")})',
               f'(property "Value" {q(self.value)} (at {f(-self.hw)} {f(self.bottom - 1.27)} 0) {font(1.27, " (justify left top)")})',
               f'(property "Footprint" "" (at 0 0 0) {font(1.27, " (hide yes)")})',
               f'(property "Datasheet" "" (at 0 0 0) {font(1.27, " (hide yes)")})',
               f'(property "Description" {q(self.desc)} (at 0 0 0) {font(1.27, " (hide yes)")})',
               f'(symbol {q(self.name + "_0_1")} (rectangle (start {f(-self.hw)} {f(self.top)}) (end {f(self.hw)} {f(self.bottom)}) '
               f'(stroke (width 0.254) (type default)) (fill (type background))))',
               f'(symbol {q(self.name + "_1_1")}']
        for pname, (x, y, ang, typ) in self.pins.items():
            out.append(f'(pin {typ} line (at {f(x)} {f(y)} {ang}) (length {f(G)}) '
                       f'(name {q(pname.rstrip("."))} {font()}) (number {q(self.numbers[pname])} {font()}))')
        out.append(')')
        out.append('(embedded_fonts no))')
        return "\n".join(out)


P_IN, P_OUT, P_BI, P_PWR, P_POUT, P_PAS = "input", "output", "bidirectional", "power_in", "power_out", "passive"

ESP32 = Module(
    "ESP32_DevKit_V1_30pin", "U", "ESP32 DevKit V1 (30-pin)",
    left=[("EN", P_IN), ("VP/IO36", P_BI), ("VN/IO39", P_BI), ("IO34", P_BI), ("IO35", P_BI), ("IO32", P_BI),
          ("IO33", P_BI), ("IO25", P_BI), ("IO26", P_BI), ("IO27", P_BI), ("IO14", P_BI), ("IO12", P_BI),
          ("IO13", P_BI), ("GND", P_PWR), ("VIN", P_PWR)],
    right=[("IO23", P_BI), ("IO22", P_BI), ("TX0/IO1", P_BI), ("RX0/IO3", P_BI), ("IO21", P_BI), ("IO19", P_BI),
           ("IO18", P_BI), ("IO5", P_BI), ("TX2/IO17", P_BI), ("RX2/IO16", P_BI), ("IO4", P_BI), ("IO2", P_BI),
           ("IO15", P_BI), ("GND.", P_PWR), ("3V3", P_POUT)],
    width=6, desc="DOIT ESP32 DevKit V1, 30 pins; VIN 5 V in, 3V3 out from the on-board regulator")
TB6612 = Module(
    "TB6612FNG_Module", "U", "TB6612FNG 馬達驅動",
    left=[("PWMA", P_IN), ("AIN1", P_IN), ("AIN2", P_IN), ("STBY", P_IN), ("BIN1", P_IN), ("BIN2", P_IN),
          ("PWMB", P_IN), ("VCC", P_PWR), ("GND", P_PWR)],
    right=[("VM", P_PWR), ("AO1", P_OUT), ("AO2", P_OUT), ("BO1", P_OUT), ("BO2", P_OUT), None, None, None,
           ("GND.", P_PWR)],
    width=4, desc="TB6612FNG dual H-bridge breakout; channel A drives the TT motor")
MOTOR = Module(
    "TT_Motor_Encoder", "M", "TT 馬達＋霍爾編碼器",
    left=[("M+", P_PAS), ("M-", P_PAS), ("VCC", P_PWR), ("GND", P_PWR), ("A", P_OUT), ("B", P_OUT)],
    width=4, desc="TT gear motor with 2-channel hall encoder (drives the rear differential)")
SERVO = Module(
    "MG90S", "M", "MG90S 轉向伺服機",
    left=[("PWM", P_IN), ("V+", P_PWR), ("GND", P_PWR)],
    width=4, desc="MG90S micro servo (orange PWM, red +, brown GND)")
BATT = Module(
    "Battery_2S_18650", "BT", "2×18650 (7.4 V) + BMS",
    right=[("B+", P_PAS), ("B-", P_POUT)],
    width=4, desc="Two 18650 cells in series with protection board")
SWITCH = Module(
    "Power_Switch", "SW", "電源開關",
    left=[("1", P_PAS)], right=[("2", P_PAS)], width=2, desc="Main power switch")
BUCK = Module(
    "Buck_5V_Module", "U", "降壓模組 5 V / 3 A",
    left=[("IN+", P_PWR), ("IN-", P_PWR)], right=[("OUT+", P_POUT), ("OUT-", P_PAS)],
    width=4, desc="MP1584 / Mini560 class buck converter set to 5.0 V")
CAP = Module(
    "CP_1000uF", "C", "1000 µF / 10 V",
    left=[("+", P_PAS)], right=[("-", P_PAS)], width=2, desc="Electrolytic capacitor near the servo")
TOF = Module(
    "VL53L0X_Module", "U", "VL53L0X ToF",
    left=[("VIN", P_PWR), ("GND", P_PWR), ("SCL", P_IN), ("SDA", P_BI), ("XSHUT", P_IN), ("GPIO1", P_OUT)],
    width=4, desc="VL53L0X time-of-flight distance sensor breakout (GY-530)")
IMU = Module(
    "MPU6050_Module", "U", "MPU6050 IMU",
    left=[("VCC", P_PWR), ("GND", P_PWR), ("SCL", P_IN), ("SDA", P_BI), ("XDA", P_BI), ("XCL", P_OUT),
          ("AD0", P_IN), ("INT", P_OUT)],
    width=4, desc="MPU6050 6-axis IMU breakout (GY-521)")
LINE = Module(
    "Line_Sensor_5ch", "U", "5 路循跡模組",
    left=[("VCC", P_PWR), ("GND", P_PWR), ("OUT1", P_OUT), ("OUT2", P_OUT), ("OUT3", P_OUT), ("OUT4", P_OUT),
          ("OUT5", P_OUT)],
    width=4, desc="5-channel TCRT5000 line tracking module")
CAM = Module(
    "ESP32_CAM", "U", "ESP32-CAM（選用）",
    left=[("5V", P_PWR), ("GND", P_PWR)],
    width=4, desc="ESP32-CAM, streams video over WiFi; only power is wired")
MODULES = [ESP32, TB6612, MOTOR, SERVO, BATT, SWITCH, BUCK, CAP, TOF, IMU, LINE, CAM]


# ---------------------------------------------------------------- KiCad power symbols (copied verbatim)
def lib_block(lib_file, name):
    text = open(os.path.join(KICAD_SYM, lib_file), encoding="utf-8").read()
    i = text.index(f'\n\t(symbol "{name}"\n') + 2
    depth, j = 0, i
    while True:
        c = text[j]
        if c == '"':  # skip strings
            j += 1
            while text[j] != '"':
                j += 2 if text[j] == "\\" else 1
        elif c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                break
        j += 1
    block = text[i:j + 1]
    assert "(extends" not in block, name
    return block.replace(f'(symbol "{name}"', f'(symbol "power:{name}"', 1)


POWER = ["GND", "+5V", "+3V3", "+BATT", "PWR_FLAG"]

# ---------------------------------------------------------------- placement
items = []          # schematic body items
pwr_count = [0]


def place_symbol(lib_id, ref, value, x, y, pins, rot=0, ref_at=None, val_at=None, val_just="left top",
                 hide_ref=False):
    pr = f"(at {f(ref_at[0])} {f(ref_at[1])} 0)" if ref_at else f"(at {f(x)} {f(y)} 0)"
    # field angles are stored relative to the symbol: undo the symbol's rotation so text stays horizontal
    va = rot % 180
    pv = f"(at {f(val_at[0])} {f(val_at[1])} {va})" if val_at else f"(at {f(x)} {f(y)} {va})"
    ref_fx = font(1.27, " (hide yes)") if hide_ref else font(1.27, " (justify left bottom)")
    val_fx = font(1.27, f" (justify {val_just})") if val_just else font(1.27)
    s = [f'(symbol (lib_id {q(lib_id)}) (at {f(x)} {f(y)} {rot}) (unit 1) (exclude_from_sim no) (in_bom yes) '
         f'(on_board yes) (dnp no) (uuid {q(uid())})',
         f'(property "Reference" {q(ref)} {pr} {ref_fx})',
         f'(property "Value" {q(value)} {pv} {val_fx})',
         f'(property "Footprint" "" (at {f(x)} {f(y)} 0) {font(1.27, " (hide yes)")})',
         f'(property "Datasheet" "" (at {f(x)} {f(y)} 0) {font(1.27, " (hide yes)")})',
         f'(property "Description" "" (at {f(x)} {f(y)} 0) {font(1.27, " (hide yes)")})']
    for p in pins:
        s.append(f'(pin {q(p)} (uuid {q(uid())}))')
    s.append(f'(instances (project {q(PROJECT)} (path {q("/" + ROOT_UUID)} (reference {q(ref)}) (unit 1)))))')
    items.append("\n".join(s))


def wire(x1, y1, x2, y2):
    items.append(f'(wire (pts (xy {f(x1)} {f(y1)}) (xy {f(x2)} {f(y2)})) (stroke (width 0) (type default)) (uuid {q(uid())}))')


def label(name, x, y, right):
    ang, just = (0, "left bottom") if right else (180, "right bottom")
    items.append(f'(label {q(name)} (at {f(x)} {f(y)} {ang}) {font(1.27, f" (justify {just})")} (uuid {q(uid())}))')


def power(name, x, y, side=None):
    """Power symbol with its pin at (x, y). side='left'/'right' lays it on its side, pointing away from the pin,
    so it stays within one 2.54 pin row; side=None keeps KiCad's upright orientation."""
    pwr_count[0] += 1
    ref = f"#FLG{pwr_count[0]:02d}" if name == "PWR_FLAG" else f"#PWR{pwr_count[0]:02d}"
    gnd = name == "GND"
    if side == "left":
        rot, val, just = (270 if gnd else 90), (x - 4.064, y), "right bottom"
    elif side == "right":
        rot, val, just = (90 if gnd else 270), (x + 4.064, y), "left bottom"
    else:
        rot, val, just = 0, (x, y + 5.08 if gnd else y - 3.81), None
    if rot == 90:  # KiCad mirrors a field's justification when the symbol is turned 90 degrees
        flip = {"left": "right", "right": "left", "bottom": "top", "top": "bottom"}
        just = " ".join(flip[w] for w in just.split())
    place_symbol(f"power:{name}", ref, name, x, y, ["1"], rot=rot, ref_at=(x, y), val_at=val, val_just=just,
                 hide_ref=True)


def no_connect(x, y):
    items.append(f'(no_connect (at {f(x)} {f(y)}) (uuid {q(uid())}))')


def text(s, x, y, size=1.27, bold=False):
    b = " (bold yes)" if bold else ""
    items.append(f'(text {q(s)} (exclude_from_sim no) (at {f(x)} {f(y)} 0) '
                 f'(effects (font (size {f(size)} {f(size)}){b}) (justify left top)) (uuid {q(uid())}))')


def frame(title, x1, y1, x2, y2):
    items.append(f'(rectangle (start {f(x1)} {f(y1)}) (end {f(x2)} {f(y2)}) (stroke (width 0.254) (type dash)) '
                 f'(fill (type none)) (uuid {q(uid())}))')
    text(title, x1 + 2.54, y1 + 2.54, 2.0, True)


STUB = 2 * G        # stub to a power symbol
LABEL_STUB = 3 * G  # labels sit one grid further out, clear of a neighbouring row's GND triangle
POWER_NETS = {"GND", "+5V", "+3V3", "+BATT"}


def put(mod, ref, x, y, conn, value=None):
    """Place module `mod` at (x, y); conn maps pin name -> net name, 'NC', or a power net."""
    place_symbol(f"{LIB}:{mod.name}", ref, value or mod.value, x, y, [mod.numbers[p] for p in mod.pins],
                 ref_at=(x - mod.hw, y - mod.top - 1.27), val_at=(x - mod.hw, y - mod.bottom + 1.27))
    for pname, (px, py, ang, _t) in mod.pins.items():
        net = conn.get(pname, "NC")
        sx, sy = x + px, y - py
        if net == "NC":
            no_connect(sx, sy)
            continue
        d = -1 if ang == 0 else 1          # stub goes left for left-side pins
        ex = sx + d * (STUB if net in POWER_NETS else LABEL_STUB)
        wire(sx, sy, ex, sy)
        if net in POWER_NETS:
            power(net, ex, sy, side="right" if d > 0 else "left")
        else:
            label(net, ex, sy, right=d > 0)


# ---------------------------------------------------------------- the circuit
# A3 sheet; row 1 power / controller / actuators, row 2 sensors, row 3 notes (left of the title block)
frame("電源 Power", 12.7, 17.78, 134.62, 111.76)
frame("主控 Controller", 139.7, 17.78, 254, 111.76)
frame("致動 Actuators", 259.08, 17.78, 406.4, 111.76)
frame("感測器 Sensors", 12.7, 116.84, 406.4, 193.04)
frame("說明 Notes", 12.7, 198.12, 292.1, 250.19)

# power: battery -> switch -> +BATT -> buck -> +5V
put(BATT, "BT1", 30.48, 43.18, {"B+": "BAT_RAW", "B-": "GND"})
put(SWITCH, "SW1", 50.8, 66.04, {"1": "BAT_RAW", "2": "+BATT"})
put(BUCK, "U1", 99.06, 43.18, {"IN+": "+BATT", "IN-": "GND", "OUT+": "+5V", "OUT-": "GND"})
put(CAP, "C1", 99.06, 68.58, {"+": "+5V", "-": "GND"})
text("C1 靠近伺服機，吸收轉向瞬間電流", 78.74, 78.74)
# power flag so ERC knows the switched battery rail (+BATT) is driven
power("+BATT", 22.86, 99.06)
wire(22.86, 99.06, 33.02, 99.06)
power("PWR_FLAG", 33.02, 99.06)
text("+BATT 在開關後，加 PWR_FLAG 標示電源來源", 38.1, 96.52)

# controller
put(ESP32, "U2", 196.85, 58.42, {
    "VP/IO36": "LINE1", "VN/IO39": "LINE2", "IO34": "LINE3", "IO35": "LINE4", "IO32": "LINE5",
    "IO33": "MOT_STBY", "IO25": "MOT_PWM", "IO26": "MOT_IN1", "IO27": "MOT_IN2", "IO13": "SERVO_PWM",
    "GND": "GND", "VIN": "+5V",
    "IO22": "SCL", "IO21": "SDA", "IO19": "ENC_B", "IO18": "ENC_A",
    "TX2/IO17": "XSHUT_R", "RX2/IO16": "XSHUT_L", "IO4": "XSHUT_F", "GND.": "GND", "3V3": "+3V3"})
text("未接：EN、IO14、IO12、IO15、IO2、IO5、IO23、TX0、RX0\n（IO0/2/5/12/15 為開機設定腳，避開不用；TX0/RX0 留給 USB）",
     144.78, 96.52)

# actuators
put(TB6612, "U3", 289.56, 50.8, {
    "PWMA": "MOT_PWM", "AIN1": "MOT_IN1", "AIN2": "MOT_IN2", "STBY": "MOT_STBY", "VCC": "+3V3", "GND": "GND",
    "VM": "+BATT", "AO1": "MOT_A", "AO2": "MOT_B", "GND.": "GND"})
put(MOTOR, "M1", 373.38, 40.64, {"M+": "MOT_A", "M-": "MOT_B", "VCC": "+3V3", "GND": "GND", "A": "ENC_A",
                                 "B": "ENC_B"})
put(SERVO, "M2", 373.38, 76.2, {"PWM": "SERVO_PWM", "V+": "+5V", "GND": "GND"})
text("TT 馬達額定 3～6 V：VM 接 7.4 V 時，PWM 上限設約 70 %\nB 通道不用（BIN1、BIN2、PWMB、BO1、BO2 不接）", 264.16, 96.52)

# sensors
SY = 147.32
put(TOF, "U4", 45.72, SY, {"VIN": "+3V3", "GND": "GND", "SCL": "SCL", "SDA": "SDA", "XSHUT": "XSHUT_F"},
    value="VL53L0X 前")
put(TOF, "U5", 109.22, SY, {"VIN": "+3V3", "GND": "GND", "SCL": "SCL", "SDA": "SDA", "XSHUT": "XSHUT_L"},
    value="VL53L0X 左前")
put(TOF, "U6", 172.72, SY, {"VIN": "+3V3", "GND": "GND", "SCL": "SCL", "SDA": "SDA", "XSHUT": "XSHUT_R"},
    value="VL53L0X 右前")
put(IMU, "U7", 236.22, SY, {"VCC": "+3V3", "GND": "GND", "SCL": "SCL", "SDA": "SDA", "AD0": "GND"})
put(LINE, "U8", 304.8, SY, {"VCC": "+3V3", "GND": "GND", "OUT1": "LINE1", "OUT2": "LINE2", "OUT3": "LINE3",
                            "OUT4": "LINE4", "OUT5": "LINE5"})
put(CAM, "U9", 375.92, 139.7, {"5V": "+5V", "GND": "GND"})
text("ESP32-CAM（選用）只接電源，\n影像用 WiFi 傳到電腦（第 4 階段）", 350.52, 152.4)
text("VL53L0X 開機預設位址都是 0x29：依序拉高 XSHUT_F／L／R，改成 0x30／0x31／0x32", 20.32, 175.26)
text("MPU6050 的 AD0 接 GND → 位址 0x68；循跡模組 VCC 接 3.3 V，輸出才不會超過 ESP32 的 3.3 V", 20.32, 180.34)

text("1. 2×18650 串聯（7.4 V，附保護板）經開關成 +BATT，直接供 TB6612 的 VM（馬達電源）\n"
     "2. 降壓模組把 +BATT 降成 +5V：供 ESP32 VIN、MG90S 伺服機、ESP32-CAM\n"
     "3. ESP32 板上穩壓器輸出 +3V3：供 VL53L0X、MPU6050、循跡模組、馬達編碼器、TB6612 邏輯（VCC）\n"
     "4. 同名標籤（例：SDA、MOT_PWM）代表相連；所有 GND 共地\n"
     "5. 腳位依 MechanicalAI〈自駕車電子元件建議方案〉第四節；用 USB 燒錄程式時可以不接電池",
     17.78, 205.74, 1.524)

# ---------------------------------------------------------------- write files
lib_syms = [m.lib_text() for m in MODULES] + [lib_block("power.kicad_sym", n) for n in POWER]
sch = "\n".join([
    "(kicad_sch (version 20250114) (generator \"eeschema\") (generator_version \"9.0\")",
    f"(uuid {q(ROOT_UUID)})",
    '(paper "A3")',
    '(title_block (title "自駕車接線圖 Autonomous Car Wiring") (date "2026-11-24") (rev "1")'
    ' (company "MechanicalAI") (comment 1 "差速轉向車：ESP32 + TB6612FNG + MG90S + 感測器")'
    ' (comment 2 "產生器：car_model/kicad/gen_schematic.py"))',
    "(lib_symbols", *lib_syms, ")",
    *items,
    '(sheet_instances (path "/" (page "1")))',
    "(embedded_fonts no))",
])
open(os.path.join(HERE, f"{PROJECT}.kicad_sch"), "w", encoding="utf-8", newline="\n").write(sch + "\n")

lib = "\n".join(["(kicad_symbol_lib (version 20241209) (generator \"gen_schematic\") (generator_version \"9.0\")",
                 *[m.lib_text(lib_prefix=False) for m in MODULES], ")"])
open(os.path.join(HERE, f"{LIB}.kicad_sym"), "w", encoding="utf-8", newline="\n").write(lib + "\n")
open(os.path.join(HERE, "sym-lib-table"), "w", encoding="utf-8", newline="\n").write(
    f'(sym_lib_table (version 7)\n  (lib (name "{LIB}")(type "KiCad")(uri "${{KIPRJMOD}}/{LIB}.kicad_sym")'
    f'(options "")(descr "Autonomous car module symbols"))\n)\n')
pro = os.path.join(HERE, f"{PROJECT}.kicad_pro")
if not os.path.exists(pro):
    open(pro, "w", encoding="utf-8", newline="\n").write(
        '{\n  "meta": {"filename": "%s.kicad_pro", "version": 3},\n  "sheets": [["%s", "Root"]]\n}\n'
        % (PROJECT, ROOT_UUID))
print("wrote", PROJECT, "with", len(items), "items")
